@extends('admin.layouts.app')

@section('page-title', 'Edit Booking')

@section('content')
<div class="container-fluid px-4 py-6">
    <!-- Header -->
    <div class="flex items-center mb-8">
        <a href="{{ route('admin.bookings.index') }}" class="mr-4 text-gray-600 hover:text-gray-900">
            <i class="fas fa-arrow-left text-xl"></i>
        </a>
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Edit Booking</h1>
            <p class="text-gray-600 mt-1">Update booking details for {{ $booking->booking_reference }}</p>
        </div>
    </div>

    <!-- Form -->
    <form action="{{ route('admin.bookings.update', $booking) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
        @csrf
        @method('PUT')

        <!-- Customer Information -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <h3 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-user text-blue-600 mr-3"></i>
                Customer Information
            </h3>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Customer Name -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Customer Name <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="text"
                        name="customer_name"
                        value="{{ old('customer_name', $booking->customer_name) }}"
                        required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('customer_name') border-red-300 @enderror"
                        placeholder="Enter customer full name"
                    >
                    @error('customer_name')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Customer Email -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Email Address <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="email"
                        name="customer_email"
                        value="{{ old('customer_email', $booking->customer_email) }}"
                        required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('customer_email') border-red-300 @enderror"
                        placeholder="customer@example.com"
                    >
                    @error('customer_email')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Customer Phone -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Phone Number <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="text"
                        name="customer_phone"
                        value="{{ old('customer_phone', $booking->customer_phone) }}"
                        required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('customer_phone') border-red-300 @enderror"
                        placeholder="+971 50 123 4567"
                    >
                    @error('customer_phone')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Customer Country -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Country
                    </label>
                    <input
                        type="text"
                        name="customer_country"
                        value="{{ old('customer_country', $booking->customer_country) }}"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('customer_country') border-red-300 @enderror"
                        placeholder="United Arab Emirates"
                    >
                    @error('customer_country')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Customer Address -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Address
                    </label>
                    <textarea
                        name="customer_address"
                        rows="3"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('customer_address') border-red-300 @enderror"
                        placeholder="Enter customer address"
                    >{{ old('customer_address', $booking->customer_address) }}</textarea>
                    @error('customer_address')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            </div>
        </div>

        <!-- Booking Details -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <h3 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-calendar-alt text-green-600 mr-3"></i>
                Booking Details
            </h3>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Package Selection -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Select Package <span class="text-red-500">*</span>
                    </label>
                    <select
                        name="package_id"
                        id="package_select"
                        required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('package_id') border-red-300 @enderror"
                    >
                        <option value="">Select a package</option>
                        @foreach($packages as $package)
                        <option value="{{ $package->id }}" data-price="{{ $package->price }}" data-visa-price="{{ $package->visa_price ?? 0 }}" {{ old('package_id', $booking->package_id) == $package->id ? 'selected' : '' }}>
                        {{ $package->title }} - ${{ number_format($package->price, 2) }}
                        </option>
                        @endforeach
                    </select>
                    @error('package_id')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Travel Date -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Travel Date <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="date"
                        name="travel_date"
                        value="{{ old('travel_date', $booking->travel_date->format('Y-m-d')) }}"
                        required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('travel_date') border-red-300 @enderror"
                    >
                    @error('travel_date')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Return Date -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Return Date
                    </label>
                    <input
                        type="date"
                        name="return_date"
                        value="{{ old('return_date', $booking->return_date?->format('Y-m-d')) }}"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('return_date') border-red-300 @enderror"
                    >
                    @error('return_date')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Number of Adults -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Number of Adults <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="number"
                        name="number_of_adults"
                        id="number_of_adults"
                        value="{{ old('number_of_adults', $booking->number_of_adults) }}"
                        min="1"
                        required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('number_of_adults') border-red-300 @enderror"
                    >
                    @error('number_of_adults')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Number of Children -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Number of Children
                    </label>
                    <input
                        type="number"
                        name="number_of_children"
                        id="number_of_children"
                        value="{{ old('number_of_children', $booking->number_of_children) }}"
                        min="0"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('number_of_children') border-red-300 @enderror"
                    >
                    @error('number_of_children')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Number of Infants -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Number of Infants
                    </label>
                    <input
                        type="number"
                        name="number_of_infants"
                        value="{{ old('number_of_infants', $booking->number_of_infants) }}"
                        min="0"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('number_of_infants') border-red-300 @enderror"
                    >
                    @error('number_of_infants')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            </div>
        </div>

        <!-- Passengers Information -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-xl font-bold text-gray-800 flex items-center">
                    <i class="fas fa-users text-amber-600 mr-3"></i>
                    Passengers Information
                </h3>
                <span class="text-sm text-gray-500" id="passenger-count">Based on number of adults and children</span>
            </div>

            <div id="passengers-container" class="space-y-4">
                <!-- Passengers will be dynamically added here -->
            </div>
        </div>

        <!-- Pricing Information -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <h3 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-dollar-sign text-purple-600 mr-3"></i>
                Pricing Information
            </h3>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Package Price -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Package Price (Per Person) <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="number"
                        name="package_price"
                        id="package_price"
                        value="{{ old('package_price', $booking->package_price) }}"
                        step="0.01"
                        min="0"
                        required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('package_price') border-red-300 @enderror"
                        placeholder="0.00"
                    >
                    @error('package_price')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Total Amount -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Total Amount <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="number"
                        name="total_amount"
                        id="total_amount"
                        value="{{ old('total_amount', $booking->total_amount) }}"
                        step="0.01"
                        min="0"
                        required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('total_amount') border-red-300 @enderror"
                        placeholder="0.00"
                    >
                    @error('total_amount')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Paid Amount -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Paid Amount
                    </label>
                    <input
                        type="number"
                        name="paid_amount"
                        id="paid_amount"
                        value="{{ old('paid_amount', $booking->paid_amount) }}"
                        step="0.01"
                        min="0"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('paid_amount') border-red-300 @enderror"
                        placeholder="0.00"
                    >
                    @error('paid_amount')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Payment Method -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Payment Method
                    </label>
                    <select
                        name="payment_method"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('payment_method') border-red-300 @enderror"
                    >
                        <option value="">Select payment method</option>
                        <option value="cash" {{ old('payment_method', $booking->payment_method) == 'cash' ? 'selected' : '' }}>Cash</option>
                        <option value="card" {{ old('payment_method', $booking->payment_method) == 'card' ? 'selected' : '' }}>Credit/Debit Card</option>
                        <option value="bank_transfer" {{ old('payment_method', $booking->payment_method) == 'bank_transfer' ? 'selected' : '' }}>Bank Transfer</option>
                        <option value="online" {{ old('payment_method', $booking->payment_method) == 'online' ? 'selected' : '' }}>Online Payment</option>
                    </select>
                    @error('payment_method')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Transaction ID -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Transaction ID
                    </label>
                    <input
                        type="text"
                        name="transaction_id"
                        value="{{ old('transaction_id', $booking->transaction_id) }}"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('transaction_id') border-red-300 @enderror"
                        placeholder="TXN123456789"
                    >
                    @error('transaction_id')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Payment Status -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Payment Status <span class="text-red-500">*</span>
                    </label>
                    <select
                        name="payment_status"
                        required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('payment_status') border-red-300 @enderror"
                    >
                        <option value="pending" {{ old('payment_status', $booking->payment_status) == 'pending' ? 'selected' : '' }}>Pending</option>
                        <option value="partial" {{ old('payment_status', $booking->payment_status) == 'partial' ? 'selected' : '' }}>Partial Payment</option>
                        <option value="paid" {{ old('payment_status', $booking->payment_status) == 'paid' ? 'selected' : '' }}>Fully Paid</option>
                        <option value="refunded" {{ old('payment_status', $booking->payment_status) == 'refunded' ? 'selected' : '' }}>Refunded</option>
                    </select>
                    @error('payment_status')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            </div>
        </div>

        <!-- Status & Notes -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <h3 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-info-circle text-orange-600 mr-3"></i>
                Status & Additional Information
            </h3>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Booking Status -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Booking Status <span class="text-red-500">*</span>
                    </label>
                    <select
                        name="status"
                        required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('status') border-red-300 @enderror"
                    >
                        <option value="pending" {{ old('status', $booking->status) == 'pending' ? 'selected' : '' }}>Pending</option>
                        <option value="confirmed" {{ old('status', $booking->status) == 'confirmed' ? 'selected' : '' }}>Confirmed</option>
                        <option value="cancelled" {{ old('status', $booking->status) == 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                        <option value="completed" {{ old('status', $booking->status) == 'completed' ? 'selected' : '' }}>Completed</option>
                    </select>
                    @error('status')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Special Requests -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Special Requests
                    </label>
                    <textarea
                        name="special_requests"
                        rows="3"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('special_requests') border-red-300 @enderror"
                        placeholder="Any special requests from the customer..."
                    >{{ old('special_requests', $booking->special_requests) }}</textarea>
                    @error('special_requests')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Admin Notes -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Admin Notes (Internal)
                    </label>
                    <textarea
                        name="admin_notes"
                        rows="3"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('admin_notes') border-red-300 @enderror"
                        placeholder="Internal notes for admin use only..."
                    >{{ old('admin_notes', $booking->admin_notes) }}</textarea>
                    @error('admin_notes')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            </div>
        </div>

        <!-- Visa Information -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <h3 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-passport text-teal-600 mr-3"></i>
                Visa Information
            </h3>

            <!-- Visa Required Checkbox -->
            <div class="mb-6">
                <label class="flex items-center cursor-pointer">
                    <input
                        type="checkbox"
                        name="visa_required"
                        id="visa_required"
                        value="1"
                        {{ old('visa_required', $booking->visa_required) ? 'checked' : '' }}
                    class="w-5 h-5 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                    >
                    <span class="ml-3 text-sm font-medium text-gray-700">Visa Required for this booking</span>
                </label>
            </div>

            <!-- Visa Fields (shown when checkbox is checked) -->
            <div id="visa_fields" class="{{ old('visa_required', $booking->visa_required) ? '' : 'hidden' }}">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <!-- Number of Visas -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Number of Visas <span class="text-red-500">*</span>
                        </label>
                        <input
                            type="number"
                            name="number_of_visas"
                            id="number_of_visas"
                            value="{{ old('number_of_visas', $booking->number_of_visas) }}"
                            min="0"
                            class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 @error('number_of_visas') border-red-300 @enderror"
                            placeholder="1"
                        >
                        @error('number_of_visas')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Visa Price Per Person -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Visa Price (Per Person)
                        </label>
                        <input
                            type="number"
                            name="visa_price_per_person"
                            id="visa_price_per_person"
                            value="{{ old('visa_price_per_person', $booking->visa_price_per_person) }}"
                            step="0.01"
                            min="0"
                            class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 @error('visa_price_per_person') border-red-300 @enderror"
                            placeholder="0.00"
                        >
                        @error('visa_price_per_person')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Total Visa Amount -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Total Visa Amount
                        </label>
                        <input
                            type="number"
                            name="total_visa_amount"
                            id="total_visa_amount"
                            value="{{ old('total_visa_amount', $booking->total_visa_amount) }}"
                            step="0.01"
                            min="0"
                            class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 bg-gray-50 @error('total_visa_amount') border-red-300 @enderror"
                            placeholder="0.00"
                            readonly
                        >
                        @error('total_visa_amount')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                @if($booking->visa_required)
                @if($booking->passport_images && count($booking->passport_images) > 0)
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-3">Existing Passport Images ({{ count($booking->passport_images) }})</label>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4" id="existingPassportImages">
                        @foreach($booking->passport_images as $index => $image)
                        <div class="relative group" data-visa-type="passport" data-image-path="{{ $image }}">
                            <img src="{{ asset('storage/' . $image) }}" alt="Passport {{ $index + 1 }}" class="w-full h-24 object-cover rounded-lg border border-gray-300">

                            <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all rounded-lg flex items-center justify-center space-x-3">
                                <!-- Download Button -->
                                <a href="{{ asset('storage/' . $image) }}" download
                                   class="opacity-0 group-hover:opacity-100 bg-white text-gray-800 px-4 py-2 rounded-lg text-sm font-medium w-28 text-center hover:bg-gray-100 transition-all flex items-center justify-center">
                                    <i class="fas fa-download mr-1"></i> Download
                                </a>

                                <!-- Delete Button -->
                                <button type="button"
                                        class="opacity-0 group-hover:opacity-100 bg-red-500 text-white px-4 py-2 rounded-lg text-sm font-medium w-28 text-center hover:bg-red-600 transition-all flex items-center justify-center"
                                        onclick="deleteVisaImage('passport', '{{ $image }}')">
                                    <i class="fas fa-trash mr-1"></i> Delete
                                </button>
                            </div>

                            <div class="absolute top-1 left-1">
                                <span class="bg-blue-500 text-white text-xs px-2 py-1 rounded">{{ $index + 1 }}</span>
                            </div>
                        </div>

                        @endforeach
                    </div>
                    <input type="hidden" name="delete_passport_images[]" id="deletePassportImagesInput">
                </div>
                @endif

                @if($booking->applicant_images && count($booking->applicant_images) > 0)
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-3">Existing Applicant Photos ({{ count($booking->applicant_images) }})</label>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4" id="existingApplicantImages">
                        @foreach($booking->applicant_images as $index => $image)
                        <div class="relative group" data-visa-type="applicant" data-image-path="{{ $image }}">
                            <img src="{{ asset('storage/' . $image) }}" alt="Applicant {{ $index + 1 }}" class="w-full h-24 object-cover rounded-lg border border-gray-300">

                            <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all rounded-lg flex items-center justify-center space-x-3">
                                <!-- Download Button -->
                                <a href="{{ asset('storage/' . $image) }}" download
                                   class="opacity-0 group-hover:opacity-100 bg-white text-gray-800 px-4 py-2 rounded-lg text-sm font-medium w-28 text-center hover:bg-gray-100 transition-all flex items-center justify-center">
                                    <i class="fas fa-download mr-1"></i> Download
                                </a>

                                <!-- Delete Button -->
                                <button type="button"
                                        class="opacity-0 group-hover:opacity-100 bg-red-500 text-white px-4 py-2 rounded-lg text-sm font-medium w-28 text-center hover:bg-red-600 transition-all flex items-center justify-center"
                                        onclick="deleteVisaImage('applicant', '{{ $image }}')">
                                    <i class="fas fa-trash mr-1"></i> Delete
                                </button>
                            </div>

                            <div class="absolute top-1 left-1">
                                <span class="bg-green-500 text-white text-xs px-2 py-1 rounded">{{ $index + 1 }}</span>
                            </div>
                        </div>

                        @endforeach
                    </div>
                    <input type="hidden" name="delete_applicant_images[]" id="deleteApplicantImagesInput">
                </div>
                @endif

                @if($booking->emirates_id_images && count($booking->emirates_id_images) > 0)
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-3">Existing Emirates ID Images ({{ count($booking->emirates_id_images) }})</label>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4" id="existingEmiratesIdImages">
                        @foreach($booking->emirates_id_images as $index => $image)
                        <div class="relative group" data-visa-type="emirates_id" data-image-path="{{ $image }}">
                            <img src="{{ asset('storage/' . $image) }}" alt="Emirates ID {{ $index + 1 }}" class="w-full h-24 object-cover rounded-lg border border-gray-300">

                            <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all rounded-lg flex items-center justify-center space-x-3">
                                <!-- Download Button -->
                                <a href="{{ asset('storage/' . $image) }}" download
                                   class="opacity-0 group-hover:opacity-100 bg-white text-gray-800 px-4 py-2 rounded-lg text-sm font-medium w-28 text-center hover:bg-gray-100 transition-all flex items-center justify-center">
                                    <i class="fas fa-download mr-1"></i> Download
                                </a>

                                <!-- Delete Button -->
                                <button type="button"
                                        class="opacity-0 group-hover:opacity-100 bg-red-500 text-white px-4 py-2 rounded-lg text-sm font-medium w-28 text-center hover:bg-red-600 transition-all flex items-center justify-center"
                                        onclick="deleteVisaImage('emirates_id', '{{ $image }}')">
                                    <i class="fas fa-trash mr-1"></i> Delete
                                </button>
                            </div>

                            <div class="absolute top-1 left-1">
                                <span class="bg-purple-500 text-white text-xs px-2 py-1 rounded">{{ $index + 1 }}</span>
                            </div>
                        </div>

                        @endforeach
                    </div>
                    <input type="hidden" name="delete_emirates_id_images[]" id="deleteEmiratesIdImagesInput">
                </div>
                @endif
                @endif

                <!-- File Upload Fields -->
                <div class="grid grid-cols-1 gap-6">
                    <!-- Passport Images Upload -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Upload Passport Images <span class="text-gray-500 text-xs">(Upload images in JPEG, JPG, or PNG format. Max 5MB each)</span>
                        </label>
                        <input
                            type="file"
                            name="passport_images[]"
                            accept="image/*"
                            multiple
                            class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 @error('passport_images.*') border-red-300 @enderror"
                        >
                        @error('passport_images.*')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                        <p class="mt-1 text-xs text-gray-500">You can select multiple images at once. New images will be added to existing ones.</p>
                    </div>

                    <!-- Applicant Images Upload -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Upload Applicant Photos <span class="text-gray-500 text-xs">(Upload images in JPEG, JPG, or PNG format. Max 5MB each)</span>
                        </label>
                        <input
                            type="file"
                            name="applicant_images[]"
                            accept="image/*"
                            multiple
                            class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 @error('applicant_images.*') border-red-300 @enderror"
                        >
                        @error('applicant_images.*')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                        <p class="mt-1 text-xs text-gray-500">You can select multiple images at once. New images will be added to existing ones.</p>
                    </div>

                    <!-- Emirates ID Images Upload -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Upload Emirates ID Images <span class="text-gray-500 text-xs">(Upload images in JPEG, JPG, or PNG format. Max 5MB each)</span>
                        </label>
                        <input
                            type="file"
                            name="emirates_id_images[]"
                            accept="image/*"
                            multiple
                            class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 @error('emirates_id_images.*') border-red-300 @enderror"
                        >
                        @error('emirates_id_images.*')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                        <p class="mt-1 text-xs text-gray-500">You can select multiple images at once. New images will be added to existing ones.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex items-center justify-end space-x-4">
            <a href="{{ route('admin.bookings.index') }}" class="px-6 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors">
                Cancel
            </a>
            <button type="submit" class="px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all duration-200 shadow-lg hover:shadow-xl">
                <i class="fas fa-save mr-2"></i>
                Update Booking
            </button>
        </div>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const packageSelect = document.getElementById('package_select');
        const packagePriceInput = document.getElementById('package_price');
        const numberOfAdults = document.getElementById('number_of_adults');
        const numberOfChildren = document.getElementById('number_of_children');
        const totalAmountInput = document.getElementById('total_amount');
        const paidAmountInput = document.getElementById('paid_amount');

        // Visa elements
        const visaRequiredCheckbox = document.getElementById('visa_required');
        const visaFields = document.getElementById('visa_fields');
        const numberOfVisas = document.getElementById('number_of_visas');
        const visaPricePerPerson = document.getElementById('visa_price_per_person');
        const totalVisaAmount = document.getElementById('total_visa_amount');

        // Passenger elements
        const existingPassengers = @json($booking->passengers_data ?? []);

        // Toggle visa fields visibility
        visaRequiredCheckbox.addEventListener('change', function() {
            if (this.checked) {
                visaFields.classList.remove('hidden');
            } else {
                visaFields.classList.add('hidden');
            }
            calculateTotal();
        });

        // Calculate visa amount
        function calculateVisaAmount() {
            const numVisas = parseInt(numberOfVisas.value) || 0;
            const visaPrice = parseFloat(visaPricePerPerson.value) || 0;
            const visaTotal = numVisas * visaPrice;
            totalVisaAmount.value = visaTotal.toFixed(2);
            return visaTotal;
        }

        // Auto-fill package price and visa price when package is selected
        packageSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const price = selectedOption.getAttribute('data-price');
            const visaPrice = selectedOption.getAttribute('data-visa-price');

            if (price) {
                packagePriceInput.value = price;
            }

            // Auto-fill visa price if available
            if (visaPrice) {
                visaPricePerPerson.value = visaPrice;
            } else {
                visaPricePerPerson.value = '0.00';
            }

            calculateTotal();
        });

        // Calculate total amount (package + visa)
        function calculateTotal() {
            const pricePerPerson = parseFloat(packagePriceInput.value) || 0;
            const adults = parseInt(numberOfAdults.value) || 0;
            const children = parseInt(numberOfChildren.value) || 0;

            // Children might be 50% price, adjust as needed
            let total = (pricePerPerson * adults) + (pricePerPerson * 0.5 * children);

            // Add visa amount if visa is required
            if (visaRequiredCheckbox.checked) {
                const visaTotal = calculateVisaAmount();
                total += visaTotal;
            }

            totalAmountInput.value = total.toFixed(2);
        }

        // Recalculate on input changes
        packagePriceInput.addEventListener('input', calculateTotal);
        numberOfAdults.addEventListener('input', calculateTotal);
        numberOfChildren.addEventListener('input', calculateTotal);

        // Visa calculation listeners
        if (numberOfVisas) {
            numberOfVisas.addEventListener('input', calculateTotal);
        }
        if (visaPricePerPerson) {
            visaPricePerPerson.addEventListener('input', calculateTotal);
        }

        // Deletion tracking for visa images
        window._visaDeleteTracker = {
            passport: [],
            applicant: [],
            emirates_id: []
        };

        window.deleteVisaImage = function(type, imagePath) {
            if (!['passport','applicant','emirates_id'].includes(type)) return;

            Swal.fire({
                title: 'Are you sure?',
                text: "Do you really want to delete this image?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Track deletion
                    window._visaDeleteTracker[type].push(imagePath);

                    // Update hidden inputs
                    const map = {
                        passport: 'deletePassportImagesInput',
                        applicant: 'deleteApplicantImagesInput',
                        emirates_id: 'deleteEmiratesIdImagesInput'
                    };
                    const inputEl = document.getElementById(map[type]);
                    if (inputEl) inputEl.value = JSON.stringify(window._visaDeleteTracker[type]);

                    // Remove from DOM - using safer selector
                    const selector = `[data-visa-type="${type}"][data-image-path="${imagePath.replace(/"/g, '\\"')}"]`;
                    const node = document.querySelector(selector);
                    if (node && node.parentElement) {
                        node.parentElement.removeChild(node);
                    }

                    Swal.fire({
                        title: 'Deleted!',
                        text: 'The image has been removed.',
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    });
                }
            });
        };

        // Generate passenger forms dynamically
        function generatePassengerForms() {
            const adults = parseInt(numberOfAdults.value) || 0;
            const children = parseInt(numberOfChildren.value) || 0;
            const total = adults + children;
            const container = document.getElementById('passengers-container');
            const countSpan = document.getElementById('passenger-count');

            countSpan.textContent = `${total} ${total === 1 ? 'passenger' : 'passengers'}`;
            container.innerHTML = '';

            // Generate forms for adults
            for (let i = 0; i < adults; i++) {
                const existingData = existingPassengers[i] || {};
                container.appendChild(createPassengerForm(i, 'adult', existingData));
            }

            // Generate forms for children
            for (let i = 0; i < children; i++) {
                const existingData = existingPassengers[adults + i] || {};
                container.appendChild(createPassengerForm(adults + i, 'child', existingData));
            }
        }

        function createPassengerForm(index, type, data = {}) {
            const today = new Date().toISOString().split('T')[0];
            const div = document.createElement('div');
            div.className = 'bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-200 rounded-xl p-6';
            div.innerHTML = `
            <div class="flex items-center mb-4">
                <span class="bg-amber-600 text-white rounded-full w-8 h-8 flex items-center justify-center mr-3 text-sm font-bold">
                    ${index + 1}
                </span>
                <h4 class="text-lg font-bold text-gray-800">${type === 'adult' ? 'Adult' : 'Child'} Passenger</h4>
            </div>

            <input type="hidden" name="passengers[${index}][type]" value="${type}">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Full Name (as per passport) <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="text"
                        name="passengers[${index}][full_name_passport]"
                        value="${data.full_name_passport || ''}"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        placeholder="Enter full name"
                        required
                    />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Date of Birth <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="date"
                        name="passengers[${index}][date_of_birth]"
                        value="${data.date_of_birth || ''}"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        max="${today}"
                        required
                    />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Gender <span class="text-red-500">*</span>
                    </label>
                    <select
                        name="passengers[${index}][gender]"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        required
                    >
                        <option value="">Select Gender</option>
                        <option value="male" ${data.gender === 'male' ? 'selected' : ''}>Male</option>
                        <option value="female" ${data.gender === 'female' ? 'selected' : ''}>Female</option>
                        <option value="other" ${data.gender === 'other' ? 'selected' : ''}>Other</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Nationality <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="text"
                        name="passengers[${index}][nationality]"
                        value="${data.nationality || ''}"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        placeholder="Enter nationality"
                        required
                    />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Passport Number <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="text"
                        name="passengers[${index}][passport_number]"
                        value="${data.passport_number || ''}"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        placeholder="Enter passport number"
                        required
                    />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Passport Expiration <span class="text-red-500">*</span>
                    </label>
                    <input
                        type="date"
                        name="passengers[${index}][passport_expiration]"
                        value="${data.passport_expiration || ''}"
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        min="${today}"
                        required
                    />
                </div>
            </div>
        `;
            return div;
        }

        // Listen for changes in passenger count
        if (numberOfAdults) {
            numberOfAdults.addEventListener('input', generatePassengerForms);
        }
        if (numberOfChildren) {
            numberOfChildren.addEventListener('input', generatePassengerForms);
        }

        // Initialize passenger forms on page load
        generatePassengerForms();

        // Initialize calculations on page load
        calculateTotal();
        if (visaRequiredCheckbox.checked) {
            calculateVisaAmount();
        }
    });
</script>
@endsection
